module.exports = {
  env: {
      "BASE_URL": "http://localhost:3000",
      "ACCESS_TOKEN_SECRET": "YOUR_ACCESS_TOKEN_SECRET",
      "REFRESH_TOKEN_SECRET": "YOUR_REFRESH_TOKEN_SECRET",
      
     
  }
}